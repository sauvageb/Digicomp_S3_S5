package com.azqore.demo.entity;

public enum PriorityTask {

    LOW,
    MEDIUM,
    HIGH

}
